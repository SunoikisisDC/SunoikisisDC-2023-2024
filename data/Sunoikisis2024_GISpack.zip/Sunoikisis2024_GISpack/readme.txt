*****************************************
Data Pack for SunoikisisDC Session 4: GIS

*****************************************

Rebecca M. Seifried
(rseifried@umass.edu)
7 Feb 2024

This data pack contains sample GIS files for use in the workshop "SunoikisisDC Digital Approaches to Cultural Heritage: Session 4 | Geographic Information Systems: From maps to analysis" (https://github.com/SunoikisisDC/SunoikisisDC-2023-2024/wiki/4.-GIS). The files are not intended for distribution. If you would like to use these data in your work, you should check with the original publishers to make sure you are abiding by their licensing requirements.

1. roman-amphitheaters.shp - point locations of amphitheaters across the Roman Empire, by Sebastian Heath. Retrieved from https://github.com/roman-amphitheaters/roman-amphitheaters. Converted from CSV to SHP and saved in the ETRS89 Extended Lambert Azimuthal Equal Area coordinate system (EPSG 3035).

2. roman-roads.shp - Polyline shapefile of ancient roads across the Roman Empire, by the Ancient World Mapping Center. Retrieved from: https://github.com/AWMC/geodata (cultural data > roads). Converted from geoJSON to SHP and saved in the ETRS89 Extended Lambert Azimuthal Equal Area coordinate system (EPSG 3035).